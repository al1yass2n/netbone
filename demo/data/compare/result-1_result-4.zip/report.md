# Netbone Comparison Report

- Subject type: comparison

## Summary

- **Result Count:** 2
- **Results:** ["EW 25%","EB 50%"]
- **Single Metric Rows:** 14
- **Pairwise Metric Rows:** 6
- **Ok Rows:** 20
- **Invalid Rows:** 0
- **Undefined Rows:** 0

## Results

| Name | Method | Filter | Original Edges | Backbone Edges | Edge Fraction |
| --- | --- | --- | --- | --- | --- |
| EW 25% | edge_weight | fraction | 78 | 20 | 0.2564102564102564 |
| EB 50% | edge_betweenness | fraction | 78 | 39 | 0.5 |

## Single Metrics

| Result | Metric | Value | Status | Explanation |
| --- | --- | --- | --- | --- |
| EW 25% | node_count | 34.0 | ok |  |
| EW 25% | edge_count | 20.0 | ok |  |
| EW 25% | node_retention | 1.0 | ok |  |
| EW 25% | edge_retention | 0.2564102564102564 | ok |  |
| EW 25% | weight_retention | 0.39826839826839827 | ok |  |
| EW 25% | connected_component_count | 19.0 | ok |  |
| EW 25% | isolated_node_count | 17.0 | ok |  |
| EB 50% | node_count | 34.0 | ok |  |
| EB 50% | edge_count | 39.0 | ok |  |
| EB 50% | node_retention | 1.0 | ok |  |
| EB 50% | edge_retention | 0.5 | ok |  |
| EB 50% | weight_retention | 0.5541125541125541 | ok |  |
| EB 50% | connected_component_count | 2.0 | ok |  |
| EB 50% | isolated_node_count | 1.0 | ok |  |

## Pairwise Metrics

| Result A | Result B | Metric | Value | Status | Explanation | Same Original Graph | Same Original Topology | Same Target |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| EW 25% | EB 50% | node_overlap | 34.0 | ok |  | true | true | true |
| EW 25% | EB 50% | edge_overlap | 12.0 | ok |  | true | true | true |
| EW 25% | EB 50% | node_jaccard | 1.0 | ok |  | true | true | true |
| EW 25% | EB 50% | edge_jaccard | 0.2553191489361702 | ok |  | true | true | true |
| EW 25% | EB 50% | node_overlap_coefficient | 1.0 | ok |  | true | true | true |
| EW 25% | EB 50% | edge_overlap_coefficient | 0.6 | ok |  | true | true | true |

## Warnings

- Fraction filter truncated tied items at the cutoff using stable id ordering.

## Limitations

- Invalid and undefined comparison rows are retained with explicit status and explanation values.

## Reproducibility

- **Result Names:** ["EW 25%","EB 50%"]
- **Pipelines:** {"EB 50%":{"filter":{"name":"fraction","parameters":{"drop_isolates":false,"fraction":0.5,"tie_policy":"exact_stable"}},"method":{"name":"edge_betweenness","parameters":{"distance_transform":"inverse","normalized":true,"weight":"weight"}},"package":{"name":"netbone","version":"0.3.0"},"schema_version":"1.0"},"EW 25%":{"filter":{"name":"fraction","parameters":{"drop_isolates":false,"fraction":0.25,"tie_policy":"exact_stable"}},"method":{"name":"edge_weight","parameters":{"weight":"weight"}},"package":{"name":"netbone","version":"0.3.0"},"schema_version":"1.0"}}

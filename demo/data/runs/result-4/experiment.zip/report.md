# Netbone Backbone Report

- Subject type: backbone_result

## Summary

- **Method:** edge_betweenness
- **Filter:** fraction
- **Original Node Count:** 34
- **Original Edge Count:** 78
- **Backbone Node Count:** 34
- **Backbone Edge Count:** 39
- **Node Fraction:** 1.0
- **Edge Fraction:** 0.5
- **Drop Isolates:** false
- **Isolated Node Count:** 1
- **Connected Component Count:** 2
- **Selected Edge Count:** 39

## Method

- **Name:** edge_betweenness
- **Display Name:** Edge Betweenness Centrality
- **Target:** edge
- **Output Type:** score
- **Primary Statistic:** edge_betweenness
- **Preferred Direction:** higher
- **Parameters:** {"distance_transform":"inverse","normalized":true,"weight":"weight"}
- **Reference:** Girvan and Newman, PNAS 99(12): 7821-7826 (2002).
- **Doi:** 10.1073/pnas.122653799

## Filter

- **Name:** fraction
- **Display Name:** Retained Fraction Filter
- **Statistic:** edge_betweenness
- **Parameters:** {"actual_count":39,"affected_tied_ids":[],"direction":"higher","drop_isolates":false,"fraction":0.5,"requested_count":39,"statistic":"edge_betweenness","strategy":"fraction","tie_policy":"exact_stable"}

## Selection

- **Target:** edge
- **Statistic:** edge_betweenness
- **Selected Count:** 39
- **Rejected Count:** 39
- **Selected Fraction:** 0.5

## Statistics

- **Row Count:** 78
- **Columns:** ["edge_id","source_id","target_id","source","target","edge_betweenness_weight","edge_betweenness_distance","edge_betweenness"]

## Pipeline

- **Schema Version:** 1.0
- **Package:** {"name":"netbone","version":"0.3.0"}
- **Method:** {"name":"edge_betweenness","parameters":{"distance_transform":"inverse","normalized":true,"weight":"weight"}}
- **Filter:** {"name":"fraction","parameters":{"drop_isolates":false,"fraction":0.5,"tie_policy":"exact_stable"}}

## Warnings

_None._

## Limitations

- Report text is deterministic and limited to computed values, registered metadata, warnings, and user-provided context.

## Reproducibility

- **Pipeline:** {"filter":{"name":"fraction","parameters":{"drop_isolates":false,"fraction":0.5,"tie_policy":"exact_stable"}},"method":{"name":"edge_betweenness","parameters":{"distance_transform":"inverse","normalized":true,"weight":"weight"}},"package":{"name":"netbone","version":"0.3.0"},"schema_version":"1.0"}
- **Method Parameters:** {"distance_transform":"inverse","normalized":true,"weight":"weight"}
- **Filter Parameters:** {"actual_count":39,"affected_tied_ids":[],"direction":"higher","drop_isolates":false,"fraction":0.5,"requested_count":39,"statistic":"edge_betweenness","strategy":"fraction","tie_policy":"exact_stable"}
- **Has Context:** true

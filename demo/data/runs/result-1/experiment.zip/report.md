# Netbone Backbone Report

- Subject type: backbone_result

## Summary

- **Method:** edge_weight
- **Filter:** fraction
- **Original Node Count:** 34
- **Original Edge Count:** 78
- **Backbone Node Count:** 34
- **Backbone Edge Count:** 20
- **Node Fraction:** 1.0
- **Edge Fraction:** 0.2564102564102564
- **Drop Isolates:** false
- **Isolated Node Count:** 17
- **Connected Component Count:** 19
- **Selected Edge Count:** 20

## Method

- **Name:** edge_weight
- **Display Name:** Edge Weight
- **Target:** edge
- **Output Type:** score
- **Primary Statistic:** score
- **Preferred Direction:** higher
- **Parameters:** {"weight":"weight"}
- **Reference:** 
- **Doi:** 

## Filter

- **Name:** fraction
- **Display Name:** Retained Fraction Filter
- **Statistic:** score
- **Parameters:** {"actual_count":20,"affected_tied_ids":[0,18,25,43,49,58,61,66,68,71,75,76],"direction":"higher","drop_isolates":false,"fraction":0.25,"requested_count":20,"statistic":"score","strategy":"fraction","tie_policy":"exact_stable"}

## Selection

- **Target:** edge
- **Statistic:** score
- **Selected Count:** 20
- **Rejected Count:** 58
- **Selected Fraction:** 0.2564102564102564

## Statistics

- **Row Count:** 78
- **Columns:** ["edge_id","source_id","target_id","source","target","score"]

## Pipeline

- **Schema Version:** 1.0
- **Package:** {"name":"netbone","version":"0.3.0"}
- **Method:** {"name":"edge_weight","parameters":{"weight":"weight"}}
- **Filter:** {"name":"fraction","parameters":{"drop_isolates":false,"fraction":0.25,"tie_policy":"exact_stable"}}

## Warnings

- Fraction filter truncated tied items at the cutoff using stable id ordering.

## Limitations

- Report text is deterministic and limited to computed values, registered metadata, warnings, and user-provided context.

## Reproducibility

- **Pipeline:** {"filter":{"name":"fraction","parameters":{"drop_isolates":false,"fraction":0.25,"tie_policy":"exact_stable"}},"method":{"name":"edge_weight","parameters":{"weight":"weight"}},"package":{"name":"netbone","version":"0.3.0"},"schema_version":"1.0"}
- **Method Parameters:** {"weight":"weight"}
- **Filter Parameters:** {"actual_count":20,"affected_tied_ids":[0,18,25,43,49,58,61,66,68,71,75,76],"direction":"higher","drop_isolates":false,"fraction":0.25,"requested_count":20,"statistic":"score","strategy":"fraction","tie_policy":"exact_stable"}
- **Has Context:** true

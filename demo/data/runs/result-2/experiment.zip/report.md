# Netbone Backbone Report

- Subject type: backbone_result

## Summary

- **Method:** edge_weight
- **Filter:** fraction
- **Original Node Count:** 34
- **Original Edge Count:** 78
- **Backbone Node Count:** 34
- **Backbone Edge Count:** 39
- **Node Fraction:** 1.0
- **Edge Fraction:** 0.5
- **Drop Isolates:** false
- **Isolated Node Count:** 10
- **Connected Component Count:** 11
- **Selected Edge Count:** 39

## Method

- **Name:** edge_weight
- **Display Name:** Edge Weight
- **Target:** edge
- **Output Type:** score
- **Primary Statistic:** score
- **Preferred Direction:** higher
- **Parameters:** {"weight":"weight"}
- **Reference:** 
- **Doi:** 

## Filter

- **Name:** fraction
- **Display Name:** Retained Fraction Filter
- **Statistic:** score
- **Parameters:** {"actual_count":39,"affected_tied_ids":[2,3,4,5,9,11,17,24,28,32,33,34,36,38,39,40,41,42,45,46,48,53,56,59,63,73,74],"direction":"higher","drop_isolates":false,"fraction":0.5,"requested_count":39,"statistic":"score","strategy":"fraction","tie_policy":"exact_stable"}

## Selection

- **Target:** edge
- **Statistic:** score
- **Selected Count:** 39
- **Rejected Count:** 39
- **Selected Fraction:** 0.5

## Statistics

- **Row Count:** 78
- **Columns:** ["edge_id","source_id","target_id","source","target","score"]

## Pipeline

- **Schema Version:** 1.0
- **Package:** {"name":"netbone","version":"0.3.0"}
- **Method:** {"name":"edge_weight","parameters":{"weight":"weight"}}
- **Filter:** {"name":"fraction","parameters":{"drop_isolates":false,"fraction":0.5,"tie_policy":"exact_stable"}}

## Warnings

- Fraction filter truncated tied items at the cutoff using stable id ordering.

## Limitations

- Report text is deterministic and limited to computed values, registered metadata, warnings, and user-provided context.

## Reproducibility

- **Pipeline:** {"filter":{"name":"fraction","parameters":{"drop_isolates":false,"fraction":0.5,"tie_policy":"exact_stable"}},"method":{"name":"edge_weight","parameters":{"weight":"weight"}},"package":{"name":"netbone","version":"0.3.0"},"schema_version":"1.0"}
- **Method Parameters:** {"weight":"weight"}
- **Filter Parameters:** {"actual_count":39,"affected_tied_ids":[2,3,4,5,9,11,17,24,28,32,33,34,36,38,39,40,41,42,45,46,48,53,56,59,63,73,74],"direction":"higher","drop_isolates":false,"fraction":0.5,"requested_count":39,"statistic":"score","strategy":"fraction","tie_policy":"exact_stable"}
- **Has Context:** true
